//
//  MoreView.swift
//  AboutMe
//
//  Created by Siraphop Pitpreecha on 11/2/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("ReactJS")
                    Text("MongoDB")
                    Text("TypeScript")
                }
                Section("Language") {
                    Text("English")
                    Text("Hindi")
                }
            }
            .navigationTitle("More Info")
        }
        
        
        
    }
}

#Preview {
    MoreView()
}
