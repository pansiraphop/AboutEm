//
//  ContentView.swift
//  AboutMe
//
//  Created by Siraphop Pitpreecha on 11/2/26.
//

import SwiftUI

struct ContentView: View {
    let hobbies = ["Coding", "Badminton", "Table Tennis"]
    
    var body: some View {
        TabView {
            Tab("About", systemImage: "person"){
                AboutView()
            }
            Tab("Contact", systemImage: "phone"){
                ContactView()
            }
            Tab("More", systemImage: "ellipsis"){
                MoreView()
            }
            
        }
        
    }
}

#Preview {
    ContentView()
}
