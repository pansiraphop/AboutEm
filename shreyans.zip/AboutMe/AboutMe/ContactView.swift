//
//  ContactView.swift
//  AboutMe
//
//  Created by Siraphop Pitpreecha on 11/2/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack{
            
            VStack {
                Link(destination: URL(string: "instagram.com/shreyansj_16")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "linkedin.com/shrynsjn")!) {
                    Text("Linkedin")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "instagram.com/shreyansj_16")!) {
                    Text("Twitter")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "instagram.com/shreyansj_16")!) {
                    Text("Website")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
            }
            
            .navigationTitle("Contact")
            
        }
    }
}

#Preview {
    ContactView()
}
