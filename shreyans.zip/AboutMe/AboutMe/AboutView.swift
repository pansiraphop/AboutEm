//
//  AboutView.swift
//  AboutMe
//
//  Created by Siraphop Pitpreecha on 11/2/26.
//

import SwiftUI

struct AboutView: View {
    let hobbies = ["Coding", "Badminton", "Table Tennis"]
    
    var body: some View {
        
        ZStack {
            
            Color.blue
                .opacity(0.2)
                .ignoresSafeArea()
            
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(32)
                    .shadow(radius: 20)
                    .padding()
                
                Text("Hey, I am Shreyans Jain")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .fontDesign(.rounded)
                    .fontDesign(.default)
                
                Text("I love \(hobbies.formatted(.list(type: .and)))")
                    .fontDesign(.default)
                
                HStack {
                    Image(systemName: "iphone")
                    Image(systemName: "macbook.gen1")
                    Image(systemName: "applewatch.watchface")
                    Image(systemName: "airpodspro.chargingcase.wireless.fill")
                    Image(systemName: "beats.headphones")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                
                Text("I have ~100,000 kilometers on Flighty")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                
                Text("Macbook Pro")
                
                
                
            }
            .padding()
            .multilineTextAlignment(.center)
            
        }
    }
    
}

#Preview {
    AboutView()
}
