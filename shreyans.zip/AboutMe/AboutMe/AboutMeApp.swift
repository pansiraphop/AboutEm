//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by Siraphop Pitpreecha on 11/2/26.
//

import SwiftUI
import SwiftData

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
